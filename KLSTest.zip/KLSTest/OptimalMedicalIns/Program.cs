﻿using System.Data;
using System.Data.OleDb;
using System.Globalization;

string finsurancePlansPath = string.Format("{0}\\{1}", Directory.GetParent(Directory.GetCurrentDirectory()).Parent.Parent.FullName, "\\Source\\InsurancePlans.csv");
string fpatientMedsPath = string.Format("{0}\\{1}", Directory.GetParent(Directory.GetCurrentDirectory()).Parent.Parent.FullName, "\\Source\\PatientMeds.csv");
bool isFirstRowHeader = true;

    string header = isFirstRowHeader ? "Yes" : "No";

    string pathOnly = Path.GetDirectoryName(fpatientMedsPath);
    string fileName = Path.GetFileName(fpatientMedsPath);

    string sql = @"SELECT * FROM [" + fileName + "]";

    using (OleDbConnection connection = new OleDbConnection(@"Provider=Microsoft.Jet.OLEDB.4.0;Data Source="+pathOnly+";Extended Properties=\"Text;HDR="+header+"\""))
    using (OleDbCommand command = new OleDbCommand(sql, connection))
    using (OleDbDataAdapter adapter = new OleDbDataAdapter(command))
    {
        DataTable dataTable = new DataTable();
        dataTable.Locale = CultureInfo.CurrentCulture;
        adapter.Fill(dataTable);
    }

string path = Path.GetDirectoryName(finsurancePlansPath);
string fileName1 = Path.GetFileName(finsurancePlansPath);

string sql1 = @"SELECT * FROM [" + fileName + "]";

using (OleDbConnection connection = new OleDbConnection(@"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + path + ";Extended Properties=\"Text;HDR=" + header + "\""))
using (OleDbCommand command = new OleDbCommand(sql1, connection))
using (OleDbDataAdapter adapter = new OleDbDataAdapter(command))
{
    DataTable dataTable = new DataTable();
    dataTable.Locale = CultureInfo.CurrentCulture;
    adapter.Fill(dataTable);
}