﻿using Newtonsoft.Json;
using System.Text;

string filePath = string.Format("{0}\\{1}", Directory.GetParent(Directory.GetCurrentDirectory()).Parent.Parent.FullName, "\\Source\\PhoneNumbers-8-digits.csv");
string fileOutPath = string.Format("{0}\\{1}", Directory.GetParent(Directory.GetCurrentDirectory()).Parent.Parent.FullName, "\\OutPut\\PhoneNumbers.csv");
StreamReader reader = null;
int length = 0;
if (File.Exists(filePath))
{
    reader = new StreamReader(File.OpenRead(filePath));
    List<object> listA = new List<object>();
    string Column = "PhoneNumber";
    while (!reader.EndOfStream)
    {
        var line = reader.ReadLine();
        var values = line.Split(',');
        int outVal = 0;
        foreach (var item in values)
        {
            bool isInt = int.TryParse(item, out outVal);
            if (isInt && item.Length == 8)
            {
                listA.Add(outVal);
            }
            else
            {
                //Console.WriteLine("Invalid Numbers {0}", item);
            }
        }
    }
    List<object> slist = listA.OrderBy(x => x).Distinct().ToList();
    slist.Insert(0, Column);
    try
    {
        string text = string.Join("<?>]", slist.ToArray());
        byte[] buffer = Encoding.UTF8.GetBytes(text);
        MemoryStream stream = new MemoryStream();
        stream.Write(buffer, 0, buffer.Length);

        stream.Position = 0;
        byte[] newBuffer = new byte[stream.Length];
        stream.Read(newBuffer, 0, newBuffer.Length);
        string newText = Encoding.UTF8.GetString(newBuffer);
        List<string> newlist = newText.Split(new string[] { "<?>]" }, StringSplitOptions.RemoveEmptyEntries).ToList();

        string strSeperator = "\n";
        StringBuilder sbOutput = new StringBuilder();
        sbOutput.AppendLine(string.Join(strSeperator, slist));
        using (StreamWriter writer = new StreamWriter(fileOutPath, false))
        {
            writer.WriteLine(sbOutput.ToString());
        }
    }
    catch (Exception ex)
    {
        Console.WriteLine("Error  (" + ex.Message + ")");
    }

}