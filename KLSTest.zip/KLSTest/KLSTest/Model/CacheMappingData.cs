﻿using Microsoft.EntityFrameworkCore;
namespace KLSTest.Model
{
    public class CacheMappingData
    {
        public class DbContextClass : DbContext
        {
            public DbContextClass(DbContextOptions<DbContextClass> options) : base(options)
            {
            }
            public DbSet<ShortURLMappingModel> Urls
            {
                get;
                set;
            }
        }
    }
}
