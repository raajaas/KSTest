﻿namespace KLSTest
{
    public class ShortURLMappingModel
    {
        private int id = 1;
        public int Id
        {
            get;set;
        }

        private string shortCode = string.Empty;
        public string ShortCode { get { return shortCode; } set { shortCode = value; } }

        private string shortUrl = string.Empty;
        public string ShortUrl { get { return shortUrl; } set { shortUrl = value; } }

        private string redirectURL = string.Empty;
        public string RedirectURL { get { return redirectURL; } set { redirectURL = value; shortCode = System.Convert.ToBase64String(BitConverter.GetBytes(Id)); } }
    }
}
