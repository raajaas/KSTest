﻿using KLSTest.CommonUtility;
using Microsoft.AspNetCore.Mvc;

namespace KLSTest.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class GetFullURLMappingController : ControllerBase
    {
        private readonly ILogger<GetFullURLMappingController> _logger;
        public static List<ShortURLMappingModel> list = null;
        private readonly ICacheUrlMapping _cacheUrlMapping;
        public GetFullURLMappingController(ILogger<GetFullURLMappingController> logger, ICacheUrlMapping cacheService)
        {
            _logger = logger;
            _cacheUrlMapping = cacheService;
        }

        [HttpGet(Name = "GetFullURLByShortURL")]
        public async Task<string> GetFullURLByShortURL(string ShortUrl)
        {
            var cacheData = _cacheUrlMapping.GetData("ShortURLMappingModel");
            if (cacheData != null)
            {
                return cacheData.Where(x => x.ShortUrl.ToLower().Equals(ShortUrl)).Select(y => y.RedirectURL).FirstOrDefault();
            }
            return ShortUrl;
        }
    }
}
