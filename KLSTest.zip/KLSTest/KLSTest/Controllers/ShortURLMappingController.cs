﻿using KLSTest.CommonUtility;
using Microsoft.AspNetCore.Mvc;
using KLSTest.Model;
using System.Runtime.Caching;

namespace KLSTest.Controllers
{

    [ApiController]
    [Route("[controller]")]
    public class ShortURLMappingController : ControllerBase
    {
        private static int id = 1;
        public static List<ShortURLMappingModel> list = null;
        private readonly ICacheUrlMapping _cacheUrlMapping;
        private readonly ILogger<ShortURLMappingController> _logger;
        public ShortURLMappingController(ILogger<ShortURLMappingController> logger, ICacheUrlMapping cacheService)
        {
            _logger = logger;            
            _cacheUrlMapping = cacheService;
        }

        [HttpPost(Name = "CreateShortUrl")]
        public async Task<string> CreateShortUrl(string FullUrl)
        {
            if (!Uri.TryCreate(FullUrl, UriKind.Absolute, out var inputUri))
            {
                HttpContext.Response.StatusCode = StatusCodes.Status400BadRequest;
                return "URL is not valid.";
            }
            ShortURLMappingModel model = new ShortURLMappingModel();
            model.Id = id;
            model.RedirectURL = FullUrl;
            var shortUrlValue = $"{HttpContext.Request.Scheme}://{HttpContext.Request.Host}/{model.ShortCode}";
            model.ShortUrl = shortUrlValue;
            id++;

            var cacheData = _cacheUrlMapping.GetData("ShortURLMappingModel");
            cacheData.Add(model);
            var expirationTime = DateTimeOffset.Now.AddHours(2.0);
            _cacheUrlMapping.SetData<IEnumerable<ShortURLMappingModel>>("ShortURLMappingModel", cacheData, expirationTime);

            return shortUrlValue;
        }

        public static async Task<string> GeFullURLByShortCode(string ShortCode)
        {
            ObjectCache _cacheUrlMapping = MemoryCache.Default;
            List<ShortURLMappingModel> cacheData = (List<ShortURLMappingModel>)_cacheUrlMapping.Get("ShortURLMappingModel");
            if (cacheData != null)
            {
                return cacheData.Where(x => x.ShortCode.ToLower().Equals(ShortCode.ToLower())).Select(y => y.RedirectURL).FirstOrDefault();
            }
            return ShortCode;
        }
    }
}
