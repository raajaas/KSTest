﻿using System.Runtime.Caching;

namespace KLSTest.CommonUtility
{
    public class CacheUrlMapping : ICacheUrlMapping
    {
        ObjectCache _memoryCache = MemoryCache.Default;
        public List<ShortURLMappingModel> GetData(string key)
        {
            try
            {
                List<ShortURLMappingModel> item = (List<ShortURLMappingModel>)_memoryCache.Get(key);
                if (item == null)
                {
                    item = new List<ShortURLMappingModel>();
                }
                return item;
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        public bool SetData<T>(string key, T value, DateTimeOffset expirationTime)
        {
            bool res = true;
            try
            {
                if (!string.IsNullOrEmpty(key))
                {
                    _memoryCache.Set(key, value, expirationTime);
                }
            }
            catch (Exception e)
            {
                throw e;
            }
            return res;
        }
        public object RemoveData(string key)
        {
            try
            {
                if (!string.IsNullOrEmpty(key))
                {
                    return _memoryCache.Remove(key);
                }
            }
            catch (Exception e)
            {
                throw e;
            }
            return false;
        }
    }
}
